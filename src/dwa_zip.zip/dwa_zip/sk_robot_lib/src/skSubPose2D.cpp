#include "sk_robot_lib/skSubPose2D.h"

skSubPose2D::skSubPose2D()
{
}

skSubPose2D::~skSubPose2D()
{
}
