#include "sk_robot_lib/skSubTwist.h"

skSubTwist::skSubTwist()
{
}

skSubTwist::~skSubTwist()
{
}
